import 'package:flutter/material.dart';
import 'package:flutter_2048_game/screens/game_screen.dart';
import 'package:flutter_2048_game/widgets/guidelines_dialog.dart';
import 'package:flutter_animate/flutter_animate.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              Colors.orange.shade200,
              Colors.orange.shade100,
            ],
          ),
        ),
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                '2048',
                style: Theme.of(context).textTheme.displayLarge?.copyWith(
                  color: Colors.brown.shade800,
                  fontWeight: FontWeight.bold,
                ),
              ).animate().fadeIn().scale(),
              const SizedBox(height: 40),
              ElevatedButton(
                onPressed: () {
                  Navigator.of(context).push(
                    MaterialPageRoute(
                      builder: (context) => const GameScreen(),
                    ),
                  );
                },
                style: ElevatedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 40,
                    vertical: 15,
                  ),
                ),
                child: const Text(
                  'Start Game',
                  style: TextStyle(fontSize: 20),
                ),
              ).animate().slideY(
                begin: 0.3,
                duration: const Duration(milliseconds: 500),
              ),
              const SizedBox(height: 20),
              TextButton(
                onPressed: () {
                  showDialog(
                    context: context,
                    builder: (context) => const GuidelinesDialog(),
                  );
                },
                child: const Text(
                  'How to Play',
                  style: TextStyle(fontSize: 16),
                ),
              ).animate().slideY(
                begin: 0.3,
                delay: const Duration(milliseconds: 200),
                duration: const Duration(milliseconds: 500),
              ),
            ],
          ),
        ),
      ),
    );
  }
}