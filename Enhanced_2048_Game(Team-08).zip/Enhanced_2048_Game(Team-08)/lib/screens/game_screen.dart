import 'package:flutter/material.dart';
import 'package:flutter_2048_game/widgets/game_grid.dart';
import 'package:flutter_2048_game/widgets/score_board.dart';
import 'package:flutter_2048_game/widgets/game_controls.dart';

class GameScreen extends StatelessWidget {
  const GameScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('2048'),
        centerTitle: true,
      ),
      body: SafeArea(
        child: Column(
          children: [
            const ScoreBoard(),
            const Expanded(
              child: GameGrid(),
            ),
            const GameControls(),
            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }
}