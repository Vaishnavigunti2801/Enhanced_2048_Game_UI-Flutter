import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';

class CongratulationsDialog extends StatelessWidget {
  final int score;
  
  const CongratulationsDialog({
    super.key,
    required this.score,
  });

  @override
  Widget build(BuildContext context) {
    return Dialog(
      child: Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(16),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(
              Icons.emoji_events,
              size: 64,
              color: Colors.orange,
            ).animate()
              .scale(duration: const Duration(milliseconds: 500))
              .then()
              .shake(),
            const SizedBox(height: 16),
            Text(
              'New High Score!',
              style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                fontWeight: FontWeight.bold,
                color: Colors.orange[800],
              ),
            ),
            const SizedBox(height: 8),
            Text(
              'Score: $score',
              style: Theme.of(context).textTheme.titleLarge,
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: () => Navigator.of(context).pop(),
              child: const Text('Continue Playing'),
            ),
          ],
        ),
      ),
    ).animate().fadeIn().scale();
  }
}