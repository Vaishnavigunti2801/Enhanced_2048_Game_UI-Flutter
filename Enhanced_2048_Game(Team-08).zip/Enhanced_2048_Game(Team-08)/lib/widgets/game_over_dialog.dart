import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:provider/provider.dart';
import 'package:flutter_2048_game/providers/game_provider.dart';

class GameOverDialog extends StatelessWidget {
  final int finalScore;

  const GameOverDialog({
    super.key,
    required this.finalScore,
  });

  @override
  Widget build(BuildContext context) {
    return Dialog(
      child: Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(16),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(
              Icons.sports_score,
              size: 64,
              color: Colors.orange,
            ).animate()
              .scale(duration: const Duration(milliseconds: 500))
              .then()
              .shake(),
            const SizedBox(height: 16),
            Text(
              'Game Over!',
              style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                fontWeight: FontWeight.bold,
                color: Colors.orange[800],
              ),
            ),
            const SizedBox(height: 8),
            Text(
              'Final Score: $finalScore',
              style: Theme.of(context).textTheme.titleLarge,
            ),
            const SizedBox(height: 20),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                TextButton(
                  onPressed: () {
                    Navigator.of(context).pop();
                    Navigator.of(context).pop(); // Return to home screen
                  },
                  child: const Text('Exit'),
                ),
                ElevatedButton(
                  onPressed: () {
                    Navigator.of(context).pop();
                    context.read<GameProvider>().initGame();
                  },
                  child: const Text('Play Again'),
                ),
              ],
            ),
          ],
        ),
      ),
    ).animate().fadeIn().scale();
  }
}