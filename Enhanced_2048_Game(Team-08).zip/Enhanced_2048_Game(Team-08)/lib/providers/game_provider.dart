import 'package:flutter/material.dart';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:math';
import 'package:flutter_2048_game/widgets/congratulations_dialog.dart';
import 'package:flutter_2048_game/widgets/game_over_dialog.dart';

class GameProvider extends ChangeNotifier {
  List<List<int>> _grid = List.generate(4, (_) => List.filled(4, 0));
  List<List<List<int>>> _undoStack = [];
  int _currentScore = 0;
  int _bestScore = 0;
  bool _gameOver = false;
  bool _hasShownHighScorePopup = false;
  final Random _random = Random();

  List<List<int>> get grid => _grid;
  int get currentScore => _currentScore;
  int get bestScore => _bestScore;
  bool get gameOver => _gameOver;

  GameProvider() {
    _loadBestScore();
    initGame();
  }

  Future<void> _loadBestScore() async {
    final prefs = await SharedPreferences.getInstance();
    _bestScore = prefs.getInt('bestScore') ?? 0;
    notifyListeners();
  }

  Future<void> _saveBestScore() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt('bestScore', _bestScore);
  }

  void initGame() {
    _grid = List.generate(4, (_) => List.filled(4, 0));
    _addNewTile();
    _addNewTile();
    _currentScore = 0;
    _gameOver = false;
    _hasShownHighScorePopup = false;
    _undoStack.clear();
    notifyListeners();
  }

  void _showGameOverDialog(BuildContext context) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => GameOverDialog(finalScore: _currentScore),
    );
  }

  void _showCongratulationsDialog(BuildContext context) {
    if (!_hasShownHighScorePopup) {
      showDialog(
        context: context,
        builder: (context) => CongratulationsDialog(score: _currentScore),
      );
      _hasShownHighScorePopup = true;
    }
  }

  void _addNewTile() {
    List<Point<int>> emptyTiles = [];
    for (int i = 0; i < 4; i++) {
      for (int j = 0; j < 4; j++) {
        if (_grid[i][j] == 0) {
          emptyTiles.add(Point(i, j));
        }
      }
    }

    if (emptyTiles.isEmpty) return;

    final Point<int> randomPoint = emptyTiles[_random.nextInt(emptyTiles.length)];
    _grid[randomPoint.x][randomPoint.y] = _random.nextDouble() < 0.9 ? 2 : 4;
  }

  void move(Direction direction, BuildContext context) {
    if (_gameOver) return;

    _undoStack.add(_deepCopyGrid(_grid));
    bool moved = false;
    int previousScore = _currentScore;

    switch (direction) {
      case Direction.up:
        moved = _moveUp();
        break;
      case Direction.down:
        moved = _moveDown();
        break;
      case Direction.left:
        moved = _moveLeft();
        break;
      case Direction.right:
        moved = _moveRight();
        break;
    }

    if (moved) {
      _addNewTile();
      if (_currentScore > _bestScore) {
        _bestScore = _currentScore;
        _saveBestScore();
        _showCongratulationsDialog(context);
      }
      _checkGameOver(context);
      notifyListeners();
    }
  }

  bool _moveLeft() {
    bool moved = false;
    for (int i = 0; i < 4; i++) {
      List<int> row = _grid[i].where((x) => x != 0).toList();
      for (int j = 0; j < row.length - 1; j++) {
        if (row[j] == row[j + 1]) {
          row[j] *= 2;
          _currentScore += row[j];
          row.removeAt(j + 1);
          moved = true;
        }
      }
      while (row.length < 4) row.add(0);
      if (!listEquals(_grid[i], row)) moved = true;
      _grid[i] = row;
    }
    return moved;
  }

  bool _moveRight() {
    bool moved = false;
    for (int i = 0; i < 4; i++) {
      List<int> row = _grid[i].where((x) => x != 0).toList();
      for (int j = row.length - 1; j > 0; j--) {
        if (row[j] == row[j - 1]) {
          row[j] *= 2;
          _currentScore += row[j];
          row.removeAt(j - 1);
          moved = true;
        }
      }
      while (row.length < 4) row.insert(0, 0);
      if (!listEquals(_grid[i], row)) moved = true;
      _grid[i] = row;
    }
    return moved;
  }

  bool _moveUp() {
    bool moved = false;
    for (int j = 0; j < 4; j++) {
      List<int> column = [_grid[0][j], _grid[1][j], _grid[2][j], _grid[3][j]]
          .where((x) => x != 0)
          .toList();
      for (int i = 0; i < column.length - 1; i++) {
        if (column[i] == column[i + 1]) {
          column[i] *= 2;
          _currentScore += column[i];
          column.removeAt(i + 1);
          moved = true;
        }
      }
      while (column.length < 4) column.add(0);
      for (int i = 0; i < 4; i++) {
        if (_grid[i][j] != column[i]) moved = true;
        _grid[i][j] = column[i];
      }
    }
    return moved;
  }

  bool _moveDown() {
    bool moved = false;
    for (int j = 0; j < 4; j++) {
      List<int> column = [_grid[0][j], _grid[1][j], _grid[2][j], _grid[3][j]]
          .where((x) => x != 0)
          .toList();
      for (int i = column.length - 1; i > 0; i--) {
        if (column[i] == column[i - 1]) {
          column[i] *= 2;
          _currentScore += column[i];
          column.removeAt(i - 1);
          moved = true;
        }
      }
      while (column.length < 4) column.insert(0, 0);
      for (int i = 0; i < 4; i++) {
        if (_grid[i][j] != column[i]) moved = true;
        _grid[i][j] = column[i];
      }
    }
    return moved;
  }

  void undo() {
    if (_undoStack.isNotEmpty) {
      _grid = _deepCopyGrid(_undoStack.removeLast());
      notifyListeners();
    }
  }

  List<List<int>> _deepCopyGrid(List<List<int>> source) {
    return source.map((row) => List<int>.from(row)).toList();
  }

  void _checkGameOver(BuildContext context) {
    if (!_canMove()) {
      _gameOver = true;
      _showGameOverDialog(context);
      notifyListeners();
    }
  }

  bool _canMove() {
    // Check for empty cells
    for (int i = 0; i < 4; i++) {
      for (int j = 0; j < 4; j++) {
        if (_grid[i][j] == 0) return true;
      }
    }

    // Check for possible merges
    for (int i = 0; i < 4; i++) {
      for (int j = 0; j < 3; j++) {
        if (_grid[i][j] == _grid[i][j + 1]) return true;
        if (_grid[j][i] == _grid[j + 1][i]) return true;
      }
    }

    return false;
  }

  String getHint() {
    // Simple hint system
    int maxValue = 0;
    Direction? suggestedDirection;

    // Simulate moves in each direction
    for (Direction direction in Direction.values) {
      List<List<int>> tempGrid = _deepCopyGrid(_grid);
      bool moved = false;
      int potentialValue = 0;

      switch (direction) {
        case Direction.up:
          moved = _moveUp();
          break;
        case Direction.down:
          moved = _moveDown();
          break;
        case Direction.left:
          moved = _moveLeft();
          break;
        case Direction.right:
          moved = _moveRight();
          break;
      }

      // Calculate potential value of this move
      for (var row in tempGrid) {
        for (var cell in row) {
          potentialValue += cell;
        }
      }

      if (moved && potentialValue > maxValue) {
        maxValue = potentialValue;
        suggestedDirection = direction;
      }

      // Restore original grid
      _grid = _deepCopyGrid(tempGrid);
    }

    if (suggestedDirection != null) {
      return 'Try moving ${suggestedDirection.toString().split('.').last}';
    }
    return 'No good moves available';
  }
}

enum Direction { up, down, left, right }